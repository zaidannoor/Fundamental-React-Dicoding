import React from 'react';

function NotFoundPage(){
    return(
        <>
            <h2>404 - PAGE NOT FOUND</h2>
            <p>This page does not exist or has been deleted.</p>
        </> 
    )
}

export default NotFoundPage;